(function ($) {

    var MutationObserver = window.MutationObserver || window.WebKitMutationObserver || window.MozMutationObserver;
    var flickr_api_key = "36e028c1798fa9cfd4009c97b95c3d76";

    function decode_base58(base58) {
        var alphabet = '123456789abcdefghijkmnopqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ' ;
        var num = base58.length;
        var decoded = 0;
        var multi = 1;
        for (var i = (num - 1) ; i >= 0 ; i--) {
            decoded = decoded + multi * alphabet.indexOf(base58[i]);
            multi = multi * alphabet.length;
        }
        return decoded;
    }

    function photo_details_from_url(photo_url) {
        if (/^https?:\/\/(?:www\.)?flickr\.com\/photos\/[^\/]+\/([^\/]+)/.test(photo_url)) {
            return { service: "flickr", id: RegExp.$1, url: photo_url };
        } else if (/^https?:\/\/(?:www\.)?flic\.kr\/p\/([^\/]+)/.test(photo_url)) {
            return { service: "flickr", id: decode_base58(RegExp.$1), url: photo_url };
        } else if (/^https?:\/\/(?:www\.|i\.)?imgur\.com\/+([^\.\/]+)/.test(photo_url)) {
            return { service: "imgur", id: RegExp.$1, url: photo_url };
        } else if (/^https?:\/\/(?:www\.)?([^\.\/]+)\.tumblr\.com\/image\/+([^\.\/]+)/.test(photo_url)) {
            return { service: "tumblr", id: RegExp.$2, subdomain: RegExp.$1, url: photo_url };
        } else if (/^https?:\/\/(?:www\.)?instagr(?:\.am|am\.com)\/p\/+([^\.\/]+)/.test(photo_url)) {
            return { service: "instagram", id: RegExp.$1, url: photo_url };
        } else {
            return null;
        }
    }

    function add_instagram_thumbnail(container, photo_url, photo_id) {
        var thumbnail_url = "https://instagr.am/p/" + photo_id + "/media?size=t"
        var thumbnail = $("<a href=\"" + photo_url + "\"><img src=\"" + thumbnail_url + "\"></a>");
        container.append(thumbnail);
    }

    function add_tumblr_thumbnail(container, photo_url, photo_id, subdomain) {
        var api_url = "http://" + subdomain + ".tumblr.com/" +
            "api/read/json?" +
            "id=" + photo_id + "&" +
            "type=photo&" +
            "callback=tumblr_json";
        var xhr = new XMLHttpRequest();
        xhr.open("GET", api_url, true);
        xhr.onreadystatechange = function() {
            if (xhr.readyState == 4) {
                var info = JSON.parse(xhr.responseText.trim().replace(/^tumblr_json\((.*)\);$/, '$1'));
                var thumbnail_url = info.posts[0]["photo-url-75"];
                var thumbnail = $("<a href=\"" + photo_url + "\"><img src=\"" + thumbnail_url + "\"></a>");
                container.append(thumbnail);
            }
        };
        xhr.send(null);
    }

    function add_flickr_thumbnail(container, photo_url, photo_id) {
        var api_url = "https://secure.flickr.com/services/rest/?" +
            "method=flickr.photos.getInfo&" +
            "api_key=" + flickr_api_key + "&" +
            "photo_id=" + photo_id + "&" +
            "format=json&nojsoncallback=1";
        var xhr = new XMLHttpRequest();
        xhr.open("GET", api_url, true);
        xhr.onreadystatechange = function() {
            if (xhr.readyState == 4) {
                var info = JSON.parse(xhr.responseText);
                var thumbnail_url = "https://" +
                    "farm" + info.photo.farm + ".staticflickr.com/" +
                    info.photo.server + "/" +
                    info.photo.id + "_" +
                    info.photo.secret + "_" +
                    "s.jpg";
                var thumbnail = $("<a href=\"" + photo_url + "\"><img src=\"" + thumbnail_url + "\"></a>");
                container.append(thumbnail);
            }
        };
        xhr.send(null);
    }

    function add_imgur_thumbnail(container, photo_url, photo_id) {
        var api_url = "https://api.imgur.com/2/image/" + photo_id + ".json";
        var xhr = new XMLHttpRequest();
        xhr.open("GET", api_url, true);
        xhr.onreadystatechange = function() {
            if (xhr.readyState == 4) {
                var info = JSON.parse(xhr.responseText);
                var thumbnail_url = info.image.links.small_square;
                var thumbnail = $("<a href=\"" + photo_url + "\"><img src=\"" + thumbnail_url + "\"></a>");
                container.append(thumbnail);
            }
        };
        xhr.send(null);
    }

    function add_thumbnails(post, photos) {
        var container = $("<div class=\"snapp-container\"><div><div class=\"snapp-thumbnails\"></div></div></div>");
        var thumbnails = container.find(".snapp-thumbnails");
        var n = 0;
        $(photos).each(function(i, photo) {
            if (photo.service == "flickr") {
                var span = $("<span></span>");
                thumbnails.append(span);
                add_flickr_thumbnail(span, photo.url, photo.id);
                n++;
            } else if (photo.service == "imgur") {
                var span = $("<span></span>");
                thumbnails.append(span);
                add_imgur_thumbnail(span, photo.url, photo.id);
                n++;
            } else if (photo.service == "tumblr") {
                var span = $("<span></span>");
                thumbnails.append(span);
                add_tumblr_thumbnail(span, photo.url, photo.id, photo.subdomain);
                n++;
            } else if (photo.service == "instagram") {
                var span = $("<span></span>");
                thumbnails.append(span);
                add_instagram_thumbnail(span, photo.url, photo.id);
                n++;
            }
        });
        post.prepend(container);
        $(thumbnails).mouseenter(function() {
            $(this).animate({width:"" + (77 * n) + "px"}, "fast");
        });
        $(thumbnails).mouseleave(function() {
            $(this).animate({width:"77px"}, "fast");
        });
    }

    function quote_post(post_container) {
        var text =
            " >> " +
            "@" + $(post_container).find(".post-text .username").first().text() + ": " +
            $(post_container).find(".post-text .post-content").first().text();
        var textarea = $(".newpost textarea").first();
        textarea.text(text);
        textarea.focus();
    }

    function process_post(post_container) {
        $(post_container).find(".body .post-text").each(function() {
            if ($(this).find(".snapp-thumbnails").length == 0) {
                var post = $(this);
                var photos = $.map($(this).find("a[href]"), function(link) {
                    return photo_details_from_url($(link).attr("href"));
                });
                if (photos.length > 0) {
                    add_thumbnails(post, photos);
                }
            }
        });
        $(post_container).find(".post-footer li > a[data-reply-to]").each(function() {
            var quote_link = $("<li class=\"yui3-u show-on-hover\"><a href=\"#\" data-quote><i class=\"icon-snappshot-quote\"></i> Quote</a></li>");
            quote_link.insertAfter($(this).parent());
            quote_link.find("a").click(function(e) {
                quote_post(post_container);
            });
        });
    }

    if (MutationObserver) {
        var observer = new MutationObserver(function(mutations) {
            mutations.forEach(function(mutation) {
                $(mutation.addedNodes).each(function() {
                    if ($(this).is(".post-container")) {
                        process_post($(this));
                    } else {
                        $(this).find(".post-container").each(function() {
                            process_post($(this));
                        });
                    }
                });
            });
        });

        var config = { subtree: true, childList: true, characterData: false, attributes: false }
        $("body").each(function() {
            observer.observe(this, config);
        });
    }

    $(".post-container").each(function() {
        process_post(this);
    });

})(jQuery);
