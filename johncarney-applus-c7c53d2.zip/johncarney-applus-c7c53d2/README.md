App+
----

App+ is a Chrome browser extension that augments alpha.app.net by adding
image thumbnails and a quote button to posts.

Installation & Usage
--------------------

1. Download the extension using the ZIP link above and unpack it.
2. In Chrome, visit chrome://extensions and check
   "Development mode".
3. Click on "Load unpacked extension..." and select the folder where you
   unpacked the extension.
4. You're done.

Now whenever you visit alpha.app.net you will see image thumbnails on posts
containing photo links, and a quote button next to "Reply".

Supported image services are:

* flick
* tumblr (limited)
* instagram
* imgur.com

If there are multiple image links per post, it will hide all but the first.
The rest will be revealed when you hover the mouse pointer over the
thumbnail.

To-do list
----------

1. Make some icons and package it up and post it to the Chrome Web Store.
2. Add image post support (very simple "post last photo from service X"
   button).

Known Issues
------------

1. Doesn't handle flickr photo sets.
2. **Tumblr support is limited** to "http://\*.tumblr.com/image/\*" urls. (Won't
   handle "http://\*.tumblr.com/post/\*").
3. Behaviour when there are lots of images is uncertain.
4. Triggers javascript "insecure content" warnings when showing imgur.com
   thumbnails (I'm not certain that anything can actually be done about this).
5. Handling of page updates may be sub-optimal.

Feedback
--------

If you have any feedback or request, you can contact me on alpha.app.net:
[@johncarney](http://alpha.app.net/johncarney).

Contribute
----------

This is really just an exercise for me, but if you feel like contributing,
feel free to fork and submit a pull request.
